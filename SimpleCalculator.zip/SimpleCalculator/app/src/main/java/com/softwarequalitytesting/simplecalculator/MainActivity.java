package com.softwarequalitytesting.simplecalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;
import android.app.Activity;
public class MainActivity extends AppCompatActivity implements OnClickListener {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText length = (EditText) findViewById(R.id.txtFirstNo);
        EditText width = (EditText) findViewById(R.id.txtSecondNo);
        TextView result = (TextView) findViewById(R.id.lblResult);


        Button add = (Button) findViewById(R.id.btnAdd);
        Button sub = (Button) findViewById(R.id.btnSub);
        Button mul = (Button) findViewById(R.id.btnMul);
        Button div = (Button) findViewById(R.id.btnDiv);

        add.setOnClickListener(this);
        sub.setOnClickListener(this);
        mul.setOnClickListener(this);
        div.setOnClickListener(this);
    }

    public void onClick(View v) {

        EditText FirstNumber = (EditText) findViewById(R.id.txtFirstNo);
        EditText SecondNumber = (EditText) findViewById(R.id.txtSecondNo);


        if (v.getId() == R.id.btnAdd) {
            // button1 action
            calculateAdd(FirstNumber.getText().toString(), SecondNumber.getText().toString());
        }

        if (v.getId() == R.id.btnSub) {
            // button2 action
            calculateSub(FirstNumber.getText().toString(), SecondNumber.getText().toString());
        }
        if (v.getId() == R.id.btnMul) {
            // button3 action
            calculateMul(FirstNumber.getText().toString(), SecondNumber.getText().toString());
        }
        if (v.getId() == R.id.btnDiv) {
            // button4 action
            calculateDiv(FirstNumber.getText().toString(), SecondNumber.getText().toString());
        }

    }

    private void calculateAdd(String clength, String cwidth) {
        TextView result = (TextView) findViewById(R.id.lblResult);
        try {

            result.setText(new Add().add(Float.parseFloat(clength),Float.parseFloat(cwidth)) + "");
        } catch (Exception e) {
            result.setText("0");
        }

    }

    private void calculateSub(String clength, String cwidth) {
        TextView result = (TextView) findViewById(R.id.lblResult);
        try {

            result.setText(new Subtract().Subtract(Float.parseFloat(clength),Float.parseFloat(cwidth)) + "");
        } catch (Exception e) {
            result.setText("0");
        }
    }

    private void calculateMul(String clength, String cwidth) {
        TextView result = (TextView) findViewById(R.id.lblResult);
        try {

            result.setText(new Multiply().Multiply(Float.parseFloat(clength),Float.parseFloat(cwidth)) + "");
        } catch (Exception e) {
            result.setText("0");
        }

    }

    private void calculateDiv(String clength, String cwidth) {
        TextView result = (TextView) findViewById(R.id.lblResult);
        try {



            result.setText(new Divide().Divide(Float.parseFloat(clength),Float.parseFloat(cwidth)) + "");
        } catch (Exception e) {
            result.setText("0");
        }

    }
}