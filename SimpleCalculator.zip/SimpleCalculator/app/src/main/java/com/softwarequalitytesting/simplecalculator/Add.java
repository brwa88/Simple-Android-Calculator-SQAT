package com.softwarequalitytesting.simplecalculator;

public class Add {


    float add(float v1, float v2 )
    {
        float Result;
        Result=v1+v2;


        return Result;
    }
}
