package com.softwarequalitytesting.simplecalculator;

public class Subtract {


    float Subtract(float v1, float v2 )
    {
        float Result;
        Result=v1-v2;


        return Result;
    }
}
