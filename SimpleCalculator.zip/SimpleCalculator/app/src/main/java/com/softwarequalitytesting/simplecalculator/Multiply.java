package com.softwarequalitytesting.simplecalculator;

public class Multiply {

    float Multiply(float v1, float v2 )
    {
        float Result;
        Result=v1*v2;


        return Result;
    }
}
