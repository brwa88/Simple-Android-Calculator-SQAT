package com.softwarequalitytesting.simplecalculator;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class MultiplyUnitTest {

    private Multiply Multiply;
    @Before
    public void setUp(){
        Multiply = new Multiply();
        System.out.println("Ready for testing");
    }

    @Test
    public void Multiplyition_isCorrect()
    {
        double MultiplyResult1 = Multiply.Multiply(9,3);
        assertEquals("Multiply is not multiplying correctly", 27, MultiplyResult1, 0.0);

        double MultiplyResult2 = Multiply.Multiply(1,1);
        assertEquals("Multiply is not multiplying correctly", 1, MultiplyResult2, 0.0);

        double MultiplyResult3 = Multiply.Multiply(3,7);
        assertEquals("Multiply is not multiplying correctly", 21, MultiplyResult3, 0.0);

        double MultiplyResult4 = Multiply.Multiply(4,3);
        assertEquals("Multiply is not multiplying correctly", 12, MultiplyResult4, 0.0);

        double MultiplyResult5 = Multiply.Multiply(2,-1);
        assertEquals("Multiply is not multiplying correctly", -2, MultiplyResult5, 0.0);

        double MultiplyResult6 = Multiply.Multiply(0,0);
        assertEquals("Multiply is not multiplying correctly", 0, MultiplyResult6, 0.0);

        double MultiplyResult7 = Multiply.Multiply(-4,2);
        assertEquals("Multiply is not multiplying correctly", -8, MultiplyResult7, 0.0);

        double MultiplyResult8 = Multiply.Multiply(20,13);
        assertEquals("Multiply is not multiplying correctly", 260, MultiplyResult8, 0.0);

        double MultiplyResult9 = Multiply.Multiply(3, 3.3f);
        assertEquals("Multiply is not multiplying correctly", 9.899999618530273, MultiplyResult9, 0.0);

        double MultiplyResult10 = Multiply.Multiply(999,2);
        assertEquals("Multiply is not multiplying correctly", 1998, MultiplyResult10, 0.0);
    }
    @After
    public void tearDown(){
        System.out.println("Done with testing");
    }
}
