package com.softwarequalitytesting.simplecalculator;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class DivideUnitTest {

    private Divide Divide;
    @Before
    public void setUp(){
        Divide = new Divide();
        System.out.println("Ready for testing");
    }


    @Test
    public void Division_isCorrect()
    {
        double DivideResult1 = Divide.Divide(9,3);
        assertEquals("Divide is not dividing correctly", 3, DivideResult1, 0.0);

        double DivideResult2 = Divide.Divide(1,1);
        assertEquals("Divide is not dividing correctly", 1, DivideResult2, 0.0);

        double DivideResult3 = Divide.Divide(7,3);
        assertEquals("Divide is not dividing correctly", 2, DivideResult3, 1.0);

        double DivideResult4 = Divide.Divide(4,3);
        assertEquals("Divide is not dividing correctly", 1, DivideResult4, 1.0);

        double DivideResult5 = Divide.Divide(2,-1);
        assertEquals("Divide is not dividing correctly", -1, DivideResult5, 1.0);

        double DivideResult6 = Divide.Divide(0,1);
        assertEquals("Divide is not dividing correctly", 0, DivideResult6, 0.0);

        double DivideResult7 = Divide.Divide(-4,2);
        assertEquals("Divide is not dividing correctly", -2, DivideResult7, 0.0);

        double DivideResult8 = Divide.Divide(20,13);
        assertEquals("Divide is not dividing correctly", 1, DivideResult8, 7.0);

        double DivideResult9 = Divide.Divide(15,50);
        assertEquals("Divide is not dividing correctly", 0, DivideResult9, 15.0);

        double DivideResult10 = Divide.Divide(999,1);
        assertEquals("Divide is not dividing correctly", 999, DivideResult10, 0.0);
    }
@After
    public void tearDown(){
        System.out.println("Done with testing");
    }
}
