package com.softwarequalitytesting.simplecalculator;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class SubtractUnitTest {

    private Subtract sub;
    @Before
    public void setUp(){
        sub = new Subtract();
        System.out.println("Ready for testing");
    }

    @Test
    public void subition_isCorrect()
    {
        double subResult1 = sub.Subtract(9,3);
        assertEquals("Subtract is not subtracting correctly", 6, subResult1, 0.0);

        double subResult2 = sub.Subtract(1,1);
        assertEquals("Subtract is not subtracting correctly", 0, subResult2, 0.0);

        double subResult3 = sub.Subtract(3,7);
        assertEquals("Subtract is not subtracting correctly", -4, subResult3, 0.0);

        double subResult4 = sub.Subtract(4,3);
        assertEquals("Subtract is not subtracting correctly", 1, subResult4, 0.0);

        double subResult5 = sub.Subtract(2,-1);
        assertEquals("Subtract is not subtracting correctly", 3, subResult5, 0.0);

        double subResult6 = sub.Subtract(0,0);
        assertEquals("Subtract is not subtracting correctly", 0, subResult6, 0.0);

        double subResult7 = sub.Subtract(-4,2);
        assertEquals("Subtract is not subtracting correctly", -6, subResult7, 0.0);

        double subResult8 = sub.Subtract(20,13);
        assertEquals("Subtract is not subtracting correctly", 7, subResult8, 0.0);

        double subResult9 = sub.Subtract(15,50);
        assertEquals("Subtract is not subtracting correctly", -35, subResult9, 0.0);

        double subResult10 = sub.Subtract(999,1);
        assertEquals("Subtract is not subtracting correctly", 998, subResult10, 0.0);
    }

    @After
    public void tearDown(){
        System.out.println("Done with testing");
    }
}
