package com.softwarequalitytesting.simplecalculator;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
public class AddUnitTest {

    private Add add;
    @Before
    public void setUp(){
        add = new Add();
        System.out.println("Ready for testing");
    }

    @Test
    public void addition_isCorrect()
    {
        double total1 = add.add(9,3);
        assertEquals("Add is not Adding correctly", 12, total1, 0.0);

        double total2 = add.add(1,1);
        assertEquals("Add is not Adding correctly", 2, total2, 0.0);

        double total3 = add.add(3,7);
        assertEquals("Add is not Adding correctly", 10, total3, 0.0);

        double total4 = add.add(4,3);
        assertEquals("Add is not Adding correctly", 7, total4, 0.0);

        double total5 = add.add(2,-1);
        assertEquals("Add is not Adding correctly", 1, total5, 0.0);

        double total6 = add.add(0,0);
        assertEquals("Add is not Adding correctly", 0, total6, 0.0);

        double total7 = add.add(-4,2);
        assertEquals("Add is not Adding correctly", -2, total7, 0.0);

        double total8 = add.add(20,13);
        assertEquals("Add is not Adding correctly", 33, total8, 0.0);

        double total9 = add.add(15,50);
        assertEquals("Add is not Adding correctly", 65, total9, 0.0);

        double total10 = add.add(999,1);
        assertEquals("Add is not Adding correctly", 1000, total10, 0.0);
    }
    @After
    public void tearDown(){
        System.out.println("Done with testing");
    }
}
