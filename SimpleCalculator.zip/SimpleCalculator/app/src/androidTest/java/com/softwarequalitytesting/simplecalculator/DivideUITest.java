package com.softwarequalitytesting.simplecalculator;

import androidx.test.espresso.Espresso;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

public class DivideUITest {



    @Rule
    public ActivityTestRule<MainActivity> rule =
            new ActivityTestRule<MainActivity>(MainActivity.class);

    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void DivideTest1() {
        Espresso.onView(withId(R.id.txtFirstNo)).perform(typeText("1"));
        Espresso.onView(withId(R.id.txtSecondNo)).perform(typeText("2"));
        Espresso.onView(withId(R.id.btnDiv)).perform(click());
        Espresso.onView(withId(R.id.lblResult)).check(matches(withText("0.5")));
    }
    @Test
    public void DivideTest2() {
        Espresso.onView(withId(R.id.txtFirstNo)).perform(typeText("2"));
        Espresso.onView(withId(R.id.txtSecondNo)).perform(typeText("5"));
        Espresso.onView(withId(R.id.btnDiv)).perform(click());
        Espresso.onView(withId(R.id.lblResult)).check(matches(withText("0.4")));
    }

    @Test
    public void DivideTest3() {
        Espresso.onView(withId(R.id.txtFirstNo)).perform(typeText(""));
        Espresso.onView(withId(R.id.txtSecondNo)).perform(typeText(""));
        Espresso.onView(withId(R.id.btnDiv)).perform(click());
        Espresso.onView(withId(R.id.lblResult)).check(matches(withText("0")));
    }

    @Test
    public void DivideTest4() {
        Espresso.onView(withId(R.id.txtFirstNo)).perform(typeText("-2.1"));
        Espresso.onView(withId(R.id.txtSecondNo)).perform(typeText("-3"));
        Espresso.onView(withId(R.id.btnDiv)).perform(click());
        Espresso.onView(withId(R.id.lblResult)).check(matches(withText("0.7")));
    }

    @Test
    public void DivideTest5() {
        Espresso.onView(withId(R.id.txtFirstNo)).perform(typeText("-100.3"));
        Espresso.onView(withId(R.id.txtSecondNo)).perform(typeText("3"));
        Espresso.onView(withId(R.id.btnDiv)).perform(click());
        Espresso.onView(withId(R.id.lblResult)).check(matches(withText("-33.433334")));
    }
    @Test
    public void DivideTest6() {
        Espresso.onView(withId(R.id.txtFirstNo)).perform(typeText("1000"));
        Espresso.onView(withId(R.id.txtSecondNo)).perform(typeText("4"));
        Espresso.onView(withId(R.id.btnDiv)).perform(click());
        Espresso.onView(withId(R.id.lblResult)).check(matches(withText("250.0")));
    }

    @Test
    public void DivideTest7() {
        Espresso.onView(withId(R.id.txtFirstNo)).perform(typeText("10"));
        Espresso.onView(withId(R.id.txtSecondNo)).perform(typeText("-9"));
        Espresso.onView(withId(R.id.btnDiv)).perform(click());
        Espresso.onView(withId(R.id.lblResult)).check(matches(withText("-1.1111112")));
    }

    @Test
    public void DivideTest8() {
        Espresso.onView(withId(R.id.txtFirstNo)).perform(typeText("3"));
        Espresso.onView(withId(R.id.txtSecondNo)).perform(typeText("3"));
        Espresso.onView(withId(R.id.btnDiv)).perform(click());
        Espresso.onView(withId(R.id.lblResult)).check(matches(withText("1.0")));
    }

    @After
    public void tearDown() throws Exception {
    }
}
