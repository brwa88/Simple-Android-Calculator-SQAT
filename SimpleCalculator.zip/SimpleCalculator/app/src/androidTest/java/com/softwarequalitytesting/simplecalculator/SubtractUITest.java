package com.softwarequalitytesting.simplecalculator;

import androidx.test.espresso.Espresso;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

public class SubtractUITest {



    @Rule
    public ActivityTestRule<MainActivity> rule =
            new ActivityTestRule<MainActivity>(MainActivity.class);

    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void SubtractTest1() {
        Espresso.onView(withId(R.id.txtFirstNo)).perform(typeText("1"));
        Espresso.onView(withId(R.id.txtSecondNo)).perform(typeText("2"));
        Espresso.onView(withId(R.id.btnSub)).perform(click());
        Espresso.onView(withId(R.id.lblResult)).check(matches(withText("-1.0")));
    }
    @Test
    public void SubtractTest2() {
        Espresso.onView(withId(R.id.txtFirstNo)).perform(typeText("2"));
        Espresso.onView(withId(R.id.txtSecondNo)).perform(typeText("2"));
        Espresso.onView(withId(R.id.btnSub)).perform(click());
        Espresso.onView(withId(R.id.lblResult)).check(matches(withText("0.0")));
    }
    @Test
    public void SubtractTest3() {
        Espresso.onView(withId(R.id.txtFirstNo)).perform(typeText("1"));
        Espresso.onView(withId(R.id.txtSecondNo)).perform(typeText("-3"));
        Espresso.onView(withId(R.id.btnSub)).perform(click());
        Espresso.onView(withId(R.id.lblResult)).check(matches(withText("4.0")));
    }
    @Test
    public void SubtractTest4() {
        Espresso.onView(withId(R.id.txtFirstNo)).perform(typeText("-1"));
        Espresso.onView(withId(R.id.txtSecondNo)).perform(typeText("-2"));
        Espresso.onView(withId(R.id.btnSub)).perform(click());
        Espresso.onView(withId(R.id.lblResult)).check(matches(withText("1.0")));
    }
    @Test
    public void SubtractTest5() {
        Espresso.onView(withId(R.id.txtFirstNo)).perform(typeText("55"));
        Espresso.onView(withId(R.id.txtSecondNo)).perform(typeText("-2"));
        Espresso.onView(withId(R.id.btnSub)).perform(click());
        Espresso.onView(withId(R.id.lblResult)).check(matches(withText("57.0")));
    }
    @Test
    public void SubtractTest6() {
        Espresso.onView(withId(R.id.txtFirstNo)).perform(typeText("-1"));
        Espresso.onView(withId(R.id.txtSecondNo)).perform(typeText("-3"));
        Espresso.onView(withId(R.id.btnSub)).perform(click());
        Espresso.onView(withId(R.id.lblResult)).check(matches(withText("2.0")));
    }
    @Test
    public void SubtractTest7() {
        Espresso.onView(withId(R.id.txtFirstNo)).perform(typeText("100"));
        Espresso.onView(withId(R.id.txtSecondNo)).perform(typeText("20"));
        Espresso.onView(withId(R.id.btnSub)).perform(click());
        Espresso.onView(withId(R.id.lblResult)).check(matches(withText("80.0")));
    }
    @Test
    public void SubtractTest8() {
        Espresso.onView(withId(R.id.txtFirstNo)).perform(typeText("20"));
        Espresso.onView(withId(R.id.txtSecondNo)).perform(typeText("6.3"));
        Espresso.onView(withId(R.id.btnSub)).perform(click());
        Espresso.onView(withId(R.id.lblResult)).check(matches(withText("13.7")));
    }

    @After
    public void tearDown() throws Exception {
    }
}
