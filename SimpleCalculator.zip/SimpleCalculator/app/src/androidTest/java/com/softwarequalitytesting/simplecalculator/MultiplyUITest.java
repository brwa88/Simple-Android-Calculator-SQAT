package com.softwarequalitytesting.simplecalculator;

import androidx.test.espresso.Espresso;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

public class MultiplyUITest {



    @Rule
    public ActivityTestRule<MainActivity> rule =
            new ActivityTestRule<MainActivity>(MainActivity.class);

    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void MultiplyTest1() {
        Espresso.onView(withId(R.id.txtFirstNo)).perform(typeText("1"));
        Espresso.onView(withId(R.id.txtSecondNo)).perform(typeText("2"));
        Espresso.onView(withId(R.id.btnMul)).perform(click());
        Espresso.onView(withId(R.id.lblResult)).check(matches(withText("2.0")));
    }
    @Test
    public void MultiplyTest2() {
        Espresso.onView(withId(R.id.txtFirstNo)).perform(typeText("2"));
        Espresso.onView(withId(R.id.txtSecondNo)).perform(typeText("5"));
        Espresso.onView(withId(R.id.btnMul)).perform(click());
        Espresso.onView(withId(R.id.lblResult)).check(matches(withText("10.0")));
    }


    @Test
    public void MultiplyTest3() {
        Espresso.onView(withId(R.id.txtFirstNo)).perform(typeText("-2"));
        Espresso.onView(withId(R.id.txtSecondNo)).perform(typeText("60"));
        Espresso.onView(withId(R.id.btnMul)).perform(click());
        Espresso.onView(withId(R.id.lblResult)).check(matches(withText("-120.0")));
    }
    @Test
    public void MultiplyTest4() {
        Espresso.onView(withId(R.id.txtFirstNo)).perform(typeText("10"));
        Espresso.onView(withId(R.id.txtSecondNo)).perform(typeText("5"));
        Espresso.onView(withId(R.id.btnMul)).perform(click());
        Espresso.onView(withId(R.id.lblResult)).check(matches(withText("50.0")));
    }
    @Test
    public void MultiplyTest5() {
        Espresso.onView(withId(R.id.txtFirstNo)).perform(typeText("3.1"));
        Espresso.onView(withId(R.id.txtSecondNo)).perform(typeText("4"));
        Espresso.onView(withId(R.id.btnMul)).perform(click());
        Espresso.onView(withId(R.id.lblResult)).check(matches(withText("12.4")));
    }


    @Test
    public void MultiplyTest6() {
        Espresso.onView(withId(R.id.txtFirstNo)).perform(typeText("20"));
        Espresso.onView(withId(R.id.txtSecondNo)).perform(typeText("10"));
        Espresso.onView(withId(R.id.btnMul)).perform(click());
        Espresso.onView(withId(R.id.lblResult)).check(matches(withText("200.0")));
    }
    public void MultiplyTest7() {
        Espresso.onView(withId(R.id.txtFirstNo)).perform(typeText("-2"));
        Espresso.onView(withId(R.id.txtSecondNo)).perform(typeText("6"));
        Espresso.onView(withId(R.id.btnMul)).perform(click());
        Espresso.onView(withId(R.id.lblResult)).check(matches(withText("-12.0")));
    }
    public void MultiplyTest8() {
        Espresso.onView(withId(R.id.txtFirstNo)).perform(typeText("0"));
        Espresso.onView(withId(R.id.txtSecondNo)).perform(typeText("3.33"));
        Espresso.onView(withId(R.id.btnMul)).perform(click());
        Espresso.onView(withId(R.id.lblResult)).check(matches(withText("0.0")));
    }
    @After
    public void tearDown() throws Exception {
    }
}
