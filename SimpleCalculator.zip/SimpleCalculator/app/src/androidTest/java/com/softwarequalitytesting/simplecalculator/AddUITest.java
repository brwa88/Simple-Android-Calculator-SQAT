package com.softwarequalitytesting.simplecalculator;

import androidx.test.espresso.Espresso;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.junit.Assert.*;

public class AddUITest {



    @Rule
    public ActivityTestRule<MainActivity> rule =
            new ActivityTestRule<MainActivity>(MainActivity.class);

    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void AddTest1() {
        Espresso.onView(withId(R.id.txtFirstNo)).perform(typeText("1"));
        Espresso.onView(withId(R.id.txtSecondNo)).perform(typeText("2"));
        Espresso.onView(withId(R.id.btnAdd)).perform(click());
        Espresso.onView(withId(R.id.lblResult)).check(matches(withText("3.0")));
    }
    @Test
    public void AddTest2() {
        Espresso.onView(withId(R.id.txtFirstNo)).perform(typeText("2"));
        Espresso.onView(withId(R.id.txtSecondNo)).perform(typeText("2"));
        Espresso.onView(withId(R.id.btnAdd)).perform(click());
        Espresso.onView(withId(R.id.lblResult)).check(matches(withText("4.0")));
    }


    @Test
    public void AddTest3() {
        Espresso.onView(withId(R.id.txtFirstNo)).perform(typeText("15"));
        Espresso.onView(withId(R.id.txtSecondNo)).perform(typeText("2"));
        Espresso.onView(withId(R.id.btnAdd)).perform(click());
        Espresso.onView(withId(R.id.lblResult)).check(matches(withText("17.0")));
    }


    @Test
    public void AddTest4() {
        Espresso.onView(withId(R.id.txtFirstNo)).perform(typeText("-2"));
        Espresso.onView(withId(R.id.txtSecondNo)).perform(typeText("50"));
        Espresso.onView(withId(R.id.btnAdd)).perform(click());
        Espresso.onView(withId(R.id.lblResult)).check(matches(withText("48.0")));
    }
    @Test
    public void AddTest5() {
        Espresso.onView(withId(R.id.txtFirstNo)).perform(typeText("-8"));
        Espresso.onView(withId(R.id.txtSecondNo)).perform(typeText("-8"));
        Espresso.onView(withId(R.id.btnAdd)).perform(click());
        Espresso.onView(withId(R.id.lblResult)).check(matches(withText("-16.0")));
    }
    @Test
    public void AddTest6() {
        Espresso.onView(withId(R.id.txtFirstNo)).perform(typeText("100"));
        Espresso.onView(withId(R.id.txtSecondNo)).perform(typeText("1000"));
        Espresso.onView(withId(R.id.btnAdd)).perform(click());
        Espresso.onView(withId(R.id.lblResult)).check(matches(withText("1100.0")));
    }
    @Test
    public void AddTest7() {
        Espresso.onView(withId(R.id.txtFirstNo)).perform(typeText("12"));
        Espresso.onView(withId(R.id.txtSecondNo)).perform(typeText("13"));
        Espresso.onView(withId(R.id.btnAdd)).perform(click());
        Espresso.onView(withId(R.id.lblResult)).check(matches(withText("25.0")));
    }


    @Test
    public void AddTest8() {
        Espresso.onView(withId(R.id.txtFirstNo)).perform(typeText("122"));
        Espresso.onView(withId(R.id.txtSecondNo)).perform(typeText("213"));
        Espresso.onView(withId(R.id.btnAdd)).perform(click());
        Espresso.onView(withId(R.id.lblResult)).check(matches(withText("335.0")));
    }

    @After
    public void tearDown() throws Exception {
    }
}
